$(document).ready(function(){
    $('a').click(function(){
        $(this).toggleClass('clicked');
    });
});